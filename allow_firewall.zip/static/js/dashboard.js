let stressChart = null; // (Kept for reference, but not used)
let currentMediaData = null; // Store the current media data for filtering

// Don't load history automatically - let user click button
let historyLoaded = false;

async function loadHistory() {
    try {
        const response = await fetch('/api/predict_history');
        const data = await response.json();
        
        if (data.success && data.history) {
            displayHistory(data.history);
        } else {
            document.getElementById('historyContainer').innerHTML = '<p class="no-history-text">No prediction history yet. Make your first prediction!</p>';
        }
    } catch (error) {
        console.error('Error loading history:', error);
        document.getElementById('historyContainer').innerHTML = '<p class="no-history-text">Unable to load history</p>';
    }
}

function toggleHistory() {
    const historySection = document.getElementById('historySection');
    const toggleBtn = document.getElementById('toggleHistoryBtn');
    
    if (historySection.classList.contains('hidden')) {
        // Show history
        historySection.classList.remove('hidden');
        toggleBtn.textContent = '📊 Hide Prediction History';
        
        // Load history if not already loaded
        if (!historyLoaded) {
            loadHistory();
            historyLoaded = true;
        }
        
        // Scroll to history section
        historySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        // Hide history
        historySection.classList.add('hidden');
        toggleBtn.textContent = '📊 View My Prediction History';
    }
}

async function clearHistory() {
    if (!confirm('Are you sure you want to delete all your prediction history? This cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch('/api/clear_history', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('historyContainer').innerHTML = '<p class="no-history-text">History cleared successfully. Make your first prediction!</p>';
            alert('History cleared successfully!');
            historyLoaded = false; // Reset flag so it reloads next time
        } else {
            alert('Error clearing history: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error clearing history:', error);
        alert('Failed to clear history. Please try again.');
    }
}

function displayHistory(history) {
    const container = document.getElementById('historyContainer');
    
    if (history.length === 0) {
        container.innerHTML = '<p class="no-history-text">No prediction history yet. Make your first prediction!</p>';
        return;
    }
    
    container.innerHTML = '';
    history.forEach(item => {
        // Parse the timestamp properly - SQLite stores as "YYYY-MM-DD HH:MM:SS"
        const timestamp = item.timestamp.replace(' ', 'T'); // Convert to ISO format
        const date = new Date(timestamp);
        
        // Format only the date in Indian format
        const dateOptions = { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            timeZone: 'Asia/Kolkata'
        };
        const formattedDate = date.toLocaleDateString('en-IN', dateOptions);
        
        const historyItem = document.createElement('div');
        historyItem.className = `history-item ${item.stressLevel.toLowerCase()}`;
        historyItem.innerHTML = `
            <div class="history-item-header">
                <span class="history-stress-level">${item.stressLevel}</span>
                <span class="history-date">${formattedDate}</span>
            </div>
            <div class="history-details">
                <div class="history-detail">
                    <span class="history-detail-label">Confidence:</span>
                    <span class="history-detail-value">${item.confidence}%</span>
                </div>
                <div class="history-detail">
                    <span class="history-detail-label">Heart Rate:</span>
                    <span class="history-detail-value">${item.heartRate} bpm</span>
                </div>
                <div class="history-detail">
                    <span class="history-detail-label">Sleep:</span>
                    <span class="history-detail-value">${item.sleepHours}h</span>
                </div>
                <div class="history-detail">
                    <span class="history-detail-label">Steps:</span>
                    <span class="history-detail-value">${item.stepsCount.toLocaleString()}</span>
                </div>
            </div>
        `;
        container.appendChild(historyItem);
    });
}

function calculateSleepQuality() {
    const sleepHours = parseFloat(document.getElementById('sleepHours').value);
    
    if (!sleepHours || sleepHours < 0) {
        document.getElementById('sleepQuality').value = '';
        return;
    }
    
    // Calculate sleep quality based on sleep hours
    // Optimal sleep is 7-9 hours, gets quality of 8-10
    // 6-7 or 9-10 hours gets 6-8
    // Less than 6 or more than 10 gets lower quality
    let quality;
    
    if (sleepHours >= 7 && sleepHours <= 9) {
        // Optimal range: quality 8-10
        quality = 8 + ((sleepHours - 7) / 2) * 2;
    } else if (sleepHours >= 6 && sleepHours < 7) {
        // Slightly low: quality 6-8
        quality = 6 + ((sleepHours - 6) * 2);
    } else if (sleepHours > 9 && sleepHours <= 10) {
        // Slightly high: quality 6-8
        quality = 8 - ((sleepHours - 9) * 2);
    } else if (sleepHours >= 5 && sleepHours < 6) {
        // Low: quality 4-6
        quality = 4 + ((sleepHours - 5) * 2);
    } else if (sleepHours > 10 && sleepHours <= 11) {
        // High: quality 4-6
        quality = 6 - ((sleepHours - 10) * 2);
    } else if (sleepHours < 5) {
        // Very low: quality 1-4
        quality = Math.max(1, sleepHours * 0.8);
    } else {
        // Very high: quality 1-4
        quality = Math.max(1, 4 - ((sleepHours - 11) * 0.5));
    }
    
    // Round to 1 decimal place
    quality = Math.round(quality * 10) / 10;
    quality = Math.max(1, Math.min(10, quality)); // Ensure it's between 1 and 10
    
    document.getElementById('sleepQuality').value = quality;
}

async function predictStress() {
    // Get input values
    const age = document.getElementById('age').value;
    const heartRate = document.getElementById('heartRate').value;
    const sleepHours = document.getElementById('sleepHours').value;
    const stepsCount = document.getElementById('stepsCount').value;
    const dayRating = document.getElementById('dayRating').value;
    const sleepQuality = document.getElementById('sleepQuality').value;

    // Validate inputs
    if (!age || !heartRate || !sleepHours || !stepsCount || !dayRating) {
        alert('Please fill in all fields');
        return;
    }
    
    // Calculate sleep quality if not already calculated
    if (!sleepQuality) {
        calculateSleepQuality();
    }

    // Show loading
    document.getElementById('loading').classList.remove('hidden');
    document.getElementById('results').classList.add('hidden');

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                age: parseFloat(age),
                heartRate: parseFloat(heartRate),
                sleepHours: parseFloat(sleepHours),
                stepsCount: parseFloat(stepsCount),
                sleepQuality: parseFloat(document.getElementById('sleepQuality').value),
                dayRating: parseFloat(dayRating)
            })
        });

        const data = await response.json();

        if (data.success) {
            displayResults(data);
        } else {
            alert('Error: ' + (data.error || 'Failed to predict stress level'));
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
        console.error('Error:', error);
    } finally {
        document.getElementById('loading').classList.add('hidden');
    }
}

function displayResults(data) {
    // Set stress level text
    document.getElementById('stressLevel').textContent = data.stressLevel;
    document.getElementById('confidence').textContent = data.confidence;

    // Update stress meter
    updateStressMeter(data.stressLevel, data.confidence);

    // Display insights
    const insightsList = document.getElementById('insightsList');
    insightsList.innerHTML = '';
    if (data.insights && data.insights.length > 0) {
        data.insights.forEach(insight => {
            const li = document.createElement('li');
            li.textContent = insight;
            insightsList.appendChild(li);
        });
    }

    // Set recommendations
    const recommendationsList = document.getElementById('recommendationsList');
    recommendationsList.innerHTML = '';
    data.recommendations.forEach(rec => {
        const li = document.createElement('li');
        li.textContent = rec;
        recommendationsList.appendChild(li);
    });

    // Display media (music and videos)
    if (data.media) {
        currentMediaData = data.media; // Store for language filtering
        displayMedia(data.media);
    }

    // Show results
    document.getElementById('results').classList.remove('hidden');

    // Reload history only if it's currently visible
    const historySection = document.getElementById('historySection');
    if (!historySection.classList.contains('hidden')) {
        loadHistory();
    } else {
        // Mark history as needing reload next time it's opened
        historyLoaded = false;
    }

    // Scroll to results
    document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function updateStressMeter(stressLevel, confidence) {
    const meterFill = document.getElementById('meterFill');
    const needle = document.getElementById('meterNeedle');

    let percentage, color, rotation;

    if (stressLevel === 'Low') {
        percentage = 20;
        color = '#10b981'; // Green
        rotation = -60; // Left side
    } else if (stressLevel === 'Medium') {
        percentage = 50;
        color = '#f59e0b'; // Amber
        rotation = 0; // Center
    } else { // High
        percentage = 80;
        color = '#ef4444'; // Red
        rotation = 60; // Right side
    }

    // Animate meter fill
    meterFill.style.width = percentage + '%';
    meterFill.style.background = `linear-gradient(90deg, ${color}, ${color}dd)`;

    // Animate needle
    needle.style.transform = `translateX(-50%) rotate(${rotation}deg)`;
    needle.style.borderBottomColor = color;
}

function displayMedia(media) {
    // Display music only
    const musicContainer = document.getElementById('musicContainer');
    musicContainer.innerHTML = '';

    if (media.songs && media.songs.length > 0) {
        media.songs.forEach(song => {
            const mediaItem = document.createElement('div');
            mediaItem.className = 'media-item';

            // Using title and type for display
            mediaItem.innerHTML = `
                <iframe src="${song.url}" allowfullscreen></iframe>
                <div class="media-item-title">
                    ${song.title}
                </div>
            `;

            musicContainer.appendChild(mediaItem);
        });
    }
}

function toggleSection(sectionId) {
    const section = document.getElementById(sectionId);
    const toggleIcon = document.getElementById(sectionId.replace('Section', 'Toggle'));
    
    section.classList.toggle('collapsed');
    toggleIcon.classList.toggle('rotated');
}

async function simulateData() {
    try {
        const response = await fetch('/api/simulate_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        const data = await response.json();

        // Populate form with simulated data
        document.getElementById('age').value = data.age;
        document.getElementById('heartRate').value = data.heartRate;
        document.getElementById('sleepHours').value = data.sleepHours;
        document.getElementById('stepsCount').value = data.stepsCount;
        document.getElementById('dayRating').value = data.dayRating;
        
        // Calculate sleep quality based on simulated sleep hours
        calculateSleepQuality();

        // Show user feedback
        const btn = event.target;
        const originalText = btn.textContent;
        btn.textContent = 'Data Loaded!';
        btn.disabled = true;

        setTimeout(() => {
            btn.textContent = originalText;
            btn.disabled = false;
        }, 2000);
    } catch (error) {
        alert('Failed to load simulated data');
        console.error('Error:', error);
    }
}

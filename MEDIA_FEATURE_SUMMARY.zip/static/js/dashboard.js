let stressChart = null; // (Kept for reference, but not used)
let currentMediaData = null; // Store the current media data for filtering

function calculateSleepQuality() {
    const sleepHours = parseFloat(document.getElementById('sleepHours').value);
    
    if (!sleepHours || sleepHours < 0) {
        document.getElementById('sleepQuality').value = '';
        return;
    }
    
    // Calculate sleep quality based on sleep hours
    // Optimal sleep is 7-9 hours, gets quality of 8-10
    // 6-7 or 9-10 hours gets 6-8
    // Less than 6 or more than 10 gets lower quality
    let quality;
    
    if (sleepHours >= 7 && sleepHours <= 9) {
        // Optimal range: quality 8-10
        quality = 8 + ((sleepHours - 7) / 2) * 2;
    } else if (sleepHours >= 6 && sleepHours < 7) {
        // Slightly low: quality 6-8
        quality = 6 + ((sleepHours - 6) * 2);
    } else if (sleepHours > 9 && sleepHours <= 10) {
        // Slightly high: quality 6-8
        quality = 8 - ((sleepHours - 9) * 2);
    } else if (sleepHours >= 5 && sleepHours < 6) {
        // Low: quality 4-6
        quality = 4 + ((sleepHours - 5) * 2);
    } else if (sleepHours > 10 && sleepHours <= 11) {
        // High: quality 4-6
        quality = 6 - ((sleepHours - 10) * 2);
    } else if (sleepHours < 5) {
        // Very low: quality 1-4
        quality = Math.max(1, sleepHours * 0.8);
    } else {
        // Very high: quality 1-4
        quality = Math.max(1, 4 - ((sleepHours - 11) * 0.5));
    }
    
    // Round to 1 decimal place
    quality = Math.round(quality * 10) / 10;
    quality = Math.max(1, Math.min(10, quality)); // Ensure it's between 1 and 10
    
    document.getElementById('sleepQuality').value = quality;
}

async function predictStress() {
    // Get input values
    const age = document.getElementById('age').value;
    const heartRate = document.getElementById('heartRate').value;
    const sleepHours = document.getElementById('sleepHours').value;
    const stepsCount = document.getElementById('stepsCount').value;
    const dayRating = document.getElementById('dayRating').value;
    const sleepQuality = document.getElementById('sleepQuality').value;

    // Validate inputs
    if (!age || !heartRate || !sleepHours || !stepsCount || !dayRating) {
        alert('Please fill in all fields');
        return;
    }
    
    // Calculate sleep quality if not already calculated
    if (!sleepQuality) {
        calculateSleepQuality();
    }

    // Show loading
    document.getElementById('loading').classList.remove('hidden');
    document.getElementById('results').classList.add('hidden');

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                age: parseFloat(age),
                heartRate: parseFloat(heartRate),
                sleepHours: parseFloat(sleepHours),
                stepsCount: parseFloat(stepsCount),
                sleepQuality: parseFloat(document.getElementById('sleepQuality').value),
                dayRating: parseFloat(dayRating)
            })
        });

        const data = await response.json();

        if (data.success) {
            displayResults(data);
        } else {
            alert('Error: ' + (data.error || 'Failed to predict stress level'));
        }
    } catch (error) {
        alert('An error occurred. Please try again.');
        console.error('Error:', error);
    } finally {
        document.getElementById('loading').classList.add('hidden');
    }
}

function displayResults(data) {
    // Set stress level text
    document.getElementById('stressLevel').textContent = data.stressLevel;
    document.getElementById('confidence').textContent = data.confidence;

    // Update stress meter
    updateStressMeter(data.stressLevel, data.confidence);

    // Display insights
    const insightsList = document.getElementById('insightsList');
    insightsList.innerHTML = '';
    if (data.insights && data.insights.length > 0) {
        data.insights.forEach(insight => {
            const li = document.createElement('li');
            li.textContent = insight;
            insightsList.appendChild(li);
        });
    }

    // Set recommendations
    const recommendationsList = document.getElementById('recommendationsList');
    recommendationsList.innerHTML = '';
    data.recommendations.forEach(rec => {
        const li = document.createElement('li');
        li.textContent = rec;
        recommendationsList.appendChild(li);
    });

    // Display media (music and videos)
    if (data.media) {
        currentMediaData = data.media; // Store for language filtering
        displayMedia(data.media);
    }

    // Show results
    document.getElementById('results').classList.remove('hidden');

    // Scroll to results
    document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function updateStressMeter(stressLevel, confidence) {
    const meterFill = document.getElementById('meterFill');
    const needle = document.getElementById('meterNeedle');

    let percentage, color, rotation;

    if (stressLevel === 'Low') {
        percentage = 20;
        color = '#10b981'; // Green
        rotation = -60; // Left side
    } else if (stressLevel === 'Medium') {
        percentage = 50;
        color = '#f59e0b'; // Amber
        rotation = 0; // Center
    } else { // High
        percentage = 80;
        color = '#ef4444'; // Red
        rotation = 60; // Right side
    }

    // Animate meter fill
    meterFill.style.width = percentage + '%';
    meterFill.style.background = `linear-gradient(90deg, ${color}, ${color}dd)`;

    // Animate needle
    needle.style.transform = `translateX(-50%) rotate(${rotation}deg)`;
    needle.style.borderBottomColor = color;
}

function displayMedia(media) {
    // Display music
    const musicContainer = document.getElementById('musicContainer');
    musicContainer.innerHTML = '';

    if (media.songs && media.songs.length > 0) {
        media.songs.forEach(song => {
            const mediaItem = document.createElement('div');
            mediaItem.className = 'media-item';
            mediaItem.setAttribute('data-language', song.language || 'english');

            // Using title and type for display
            mediaItem.innerHTML = `
                <iframe src="${song.url}" allowfullscreen></iframe>
                <div class="media-item-title">
                    ${song.title}
                    <span class="media-item-type">${song.language ? song.language.charAt(0).toUpperCase() + song.language.slice(1) : ''}</span>
                </div>
            `;

            musicContainer.appendChild(mediaItem);
        });
    }

    // Display videos
    const videoContainer = document.getElementById('videoContainer');
    videoContainer.innerHTML = '';

    if (media.videos && media.videos.length > 0) {
        media.videos.forEach(video => {
            const mediaItem = document.createElement('div');
            mediaItem.className = 'media-item';
            mediaItem.setAttribute('data-language', video.language || 'english');

            // Using title and type for display
            mediaItem.innerHTML = `
                <iframe src="${video.url}" allowfullscreen></iframe>
                <div class="media-item-title">
                    ${video.title}
                    <span class="media-item-type">${video.language ? video.language.charAt(0).toUpperCase() + video.language.slice(1) : ''}</span>
                </div>
            `;

            videoContainer.appendChild(mediaItem);
        });
    }
}

function filterVideosByLanguage() {
    const selectedLanguage = document.getElementById('videoLanguage').value;
    const videoItems = document.querySelectorAll('#videoContainer .media-item');

    videoItems.forEach(item => {
        const itemLanguage = item.getAttribute('data-language');
        
        if (selectedLanguage === 'all' || itemLanguage === selectedLanguage) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function filterMusicByLanguage() {
    const selectedLanguage = document.getElementById('musicLanguage').value;
    const musicItems = document.querySelectorAll('#musicContainer .media-item');

    musicItems.forEach(item => {
        const itemLanguage = item.getAttribute('data-language');
        
        if (selectedLanguage === 'all' || itemLanguage === selectedLanguage) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function toggleSection(sectionId) {
    const section = document.getElementById(sectionId);
    const toggleIcon = document.getElementById(sectionId.replace('Section', 'Toggle'));
    
    section.classList.toggle('collapsed');
    toggleIcon.classList.toggle('rotated');
    
    // Reset language filter when opening section
    if (!section.classList.contains('collapsed')) {
        if (sectionId === 'musicSection') {
            const musicLangSelect = document.getElementById('musicLanguage');
            if (musicLangSelect) {
                musicLangSelect.value = 'all';
                filterMusicByLanguage();
            }
        } else if (sectionId === 'videoSection') {
            const videoLangSelect = document.getElementById('videoLanguage');
            if (videoLangSelect) {
                videoLangSelect.value = 'all';
                filterVideosByLanguage();
            }
        }
    }
}

async function simulateData() {
    try {
        const response = await fetch('/api/simulate_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        const data = await response.json();

        // Populate form with simulated data
        document.getElementById('age').value = data.age;
        document.getElementById('heartRate').value = data.heartRate;
        document.getElementById('sleepHours').value = data.sleepHours;
        document.getElementById('stepsCount').value = data.stepsCount;
        document.getElementById('dayRating').value = data.dayRating;
        
        // Calculate sleep quality based on simulated sleep hours
        calculateSleepQuality();

        // Show user feedback
        const btn = event.target;
        const originalText = btn.textContent;
        btn.textContent = 'Data Loaded!';
        btn.disabled = true;

        setTimeout(() => {
            btn.textContent = originalText;
            btn.disabled = false;
        }, 2000);
    } catch (error) {
        alert('Failed to load simulated data');
        console.error('Error:', error);
    }
}

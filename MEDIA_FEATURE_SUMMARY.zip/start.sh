#!/bin/bash
echo "Starting ZenStressy Application..."
echo ""
python3 app.py


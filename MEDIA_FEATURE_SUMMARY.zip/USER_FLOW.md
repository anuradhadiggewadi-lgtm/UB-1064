# ZenStressy User Flow

## 🎯 Complete User Journey

```
┌─────────────────────────────────────────────────────────────────┐
│                        HOME PAGE                                 │
│  • Beautiful landing page                                       │
│  • Feature showcase                                             │
│  • "Get Started" button                                         │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                       LOGIN PAGE                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Email: demo@example.com                                  │   │
│  │ Password: ••••••••                                       │   │
│  │ [Sign In]                                                │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Demo credentials displayed                                      │
└─────────────────────────────────────────────────────────────────┘
                                │
                       [Authentication]
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      DASHBOARD                                   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │           Wearable Data Input                            │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ Heart Rate:     [70    ] bpm                             │   │
│  │ Sleep Hours:    [7.5   ] hours                           │   │
│  │ Steps Count:    [8000  ] steps                           │   │
│  │ Resting HR:     [60    ] bpm                             │   │
│  │ Sleep Quality:  [7     ] (1-10)                          │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ [Simulate Data] [Predict Stress Level]                   │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│                            ▼                                    │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    LOADING...                            │   │
│  │                🤖 Analyzing data...                      │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│                            ▼                                    │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │          YOUR STRESS LEVEL: MEDIUM                       │   │
│  │            Confidence: 78.5%                             │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │         PREDICTION PROBABILITIES                         │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ Low:    ████░░░░░░░░░░░░░░░░░░░░░ 15.2%                 │   │
│  │ Medium: ████████████████████░░░░░ 78.5%                 │   │
│  │ High:   ███░░░░░░░░░░░░░░░░░░░░░░  6.3%                 │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │        💡 POSITIVE RECOMMENDATIONS                       │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ • Try to get at least 7-8 hours of sleep tonight        │   │
│  │ • Take short breaks every hour during work               │   │
│  │ • Go for a 20-minute walk to reduce stress               │   │
│  │ • Practice deep breathing exercises                      │   │
│  │ • Listen to calming music for 15 minutes                 │   │
│  │ • Consider reducing caffeine intake                      │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│                    [Logout]                                     │
└─────────────────────────────────────────────────────────────────┘
```

## 🔄 Data Flow

```
┌─────────────┐
│  User Input │
│  Wearable   │
│    Data     │
└──────┬──────┘
       │
       ▼
┌────────────────────────────────────┐
│      JavaScript Validation         │
│  • Check all fields filled         │
│  • Validate number ranges          │
└──────┬─────────────────────────────┘
       │
       ▼
┌────────────────────────────────────┐
│     API POST /api/predict          │
│     JSON Payload                   │
└──────┬─────────────────────────────┘
       │
       ▼
┌────────────────────────────────────┐
│      Flask Backend                 │
│  • Session check                   │
│  • Input extraction                │
└──────┬─────────────────────────────┘
       │
       ▼
┌────────────────────────────────────┐
│    Machine Learning Model          │
│  • Feature scaling                 │
│  • Random Forest prediction        │
│  • Probability calculation         │
└──────┬─────────────────────────────┘
       │
       ▼
┌────────────────────────────────────┐
│   Recommendations Engine           │
│  • Match stress level              │
│  • Generate personalized tips      │
└──────┬─────────────────────────────┘
       │
       ▼
┌────────────────────────────────────┐
│   JSON Response                    │
│  • Stress level                    │
│  • Confidence score                │
│  • Probabilities                   │
│  • Recommendations array           │
└──────┬─────────────────────────────┘
       │
       ▼
┌────────────────────────────────────┐
│      Frontend Display              │
│  • Visual stress indicator         │
│  • Probability bars                │
│  • Recommendations list            │
└────────────────────────────────────┘
```

## 🎨 UI Screens

### 1️⃣ Home Page
- Gradient purple background
- Hero section with logo
- Three feature cards
- Call-to-action button

### 2️⃣ Login Page
- White card on gradient
- Email/password fields
- Demo credentials shown
- Error message area

### 3️⃣ Dashboard
- Top navigation bar
- Data input section
- Results display area
- Three info cards at bottom

## 🎯 User Actions

| Action | Input | Output |
|--------|-------|--------|
| Login | Email + Password | Dashboard Access |
| Simulate | None | Auto-filled data |
| Predict | 5 data fields | Stress level + Recommendations |
| Logout | None | Back to Home |

## 📊 Stress Levels

### 🟢 LOW STRESS
- Color: Green gradient
- Probabilities: Low > 50%
- Recommendations: 4 positive tips

### 🟡 MEDIUM STRESS
- Color: Orange gradient
- Probabilities: Medium > 50%
- Recommendations: 6 adjustment tips

### 🔴 HIGH STRESS
- Color: Red gradient
- Probabilities: High > 50%
- Recommendations: 10 urgent tips

## 🔐 Session Management

```
Login → Session Created → Dashboard Access
         ↓
    [Protected Routes]
         ↓
    Logout → Session Cleared → Back to Home
```

## ✨ Key Features

1. **One-Click Simulation**: Instantly test with realistic data
2. **Real-time Prediction**: Instant ML analysis
3. **Visual Feedback**: Color-coded stress indicators
4. **Probability Display**: See all prediction levels
5. **Personalized Tips**: Tailored to stress level
6. **Responsive Design**: Works on all devices
7. **Error Handling**: User-friendly messages
8. **Loading States**: Visual feedback during processing

---

**Total Time to Predict**: ~2-3 seconds
**User Interaction**: < 1 minute
**Stress Level Accuracy**: Reasonable estimates based on physiological data

